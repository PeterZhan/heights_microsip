// DialogWeb2.cpp : implementation file
//

#include "stdafx.h"
#include "microsip.h"
#include "DialogWeb2.h"
#include "afxdialogex.h"


// CDialogWeb2 dialog

IMPLEMENT_DYNAMIC(CDialogWeb2, CDialogEx)

CDialogWeb2::CDialogWeb2(CWnd* pParent /*=NULL*/)
	: CDialogEx(CDialogWeb2::IDD, pParent)
{

}

CDialogWeb2::~CDialogWeb2()
{
}

void CDialogWeb2::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDialogWeb2, CDialogEx)
END_MESSAGE_MAP()


// CDialogWeb2 message handlers
