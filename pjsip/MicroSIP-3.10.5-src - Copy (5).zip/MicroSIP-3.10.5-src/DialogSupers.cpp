// DialogSupers.cpp : implementation file
//

#include "stdafx.h"
#include "microsip.h"
#include "DialogSupers.h"
#include "afxdialogex.h"
#include "const.h"


// CDialogSupers dialog

//IMPLEMENT_DYNAMIC(CDialogSupers, CBaseDialog)

CDialogSupers::CDialogSupers(CWnd* pParent /*=NULL*/)
	: CBaseDialog(CDialogSupers::IDD, pParent)
{
	Create(IDD, pParent);
}

CDialogSupers::~CDialogSupers()
{
}

void CDialogSupers::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EXP, m_exp);
}


BEGIN_MESSAGE_MAP(CDialogSupers, CBaseDialog)
END_MESSAGE_MAP()


// CDialogSupers message handlers


BOOL CDialogSupers::OnInitDialog()
{
	CBaseDialog::OnInitDialog();

	

	AutoMove(IDC_EXP, 0, 0, 100, 100);

	//TranslateDialog(this->m_hWnd);




	CString supersUrl = _T(SUPERS_URL);
	m_exp.Navigate(supersUrl, NULL, NULL, NULL, NULL);
	// TODO:  Add extra initialization here

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}
BEGIN_EVENTSINK_MAP(CDialogSupers, CBaseDialog)
	ON_EVENT(CDialogSupers, IDC_EXP, 250, CDialogSupers::BeforeNavigate2Exp, VTS_DISPATCH VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PBOOL)
END_EVENTSINK_MAP()


void CDialogSupers::BeforeNavigate2Exp(LPDISPATCH pDisp, VARIANT* URL, VARIANT* Flags, VARIANT* TargetFrameName, VARIANT* PostData, VARIANT* Headers, BOOL* Cancel)
{
	// TODO: Add your message handler code here




	
}
